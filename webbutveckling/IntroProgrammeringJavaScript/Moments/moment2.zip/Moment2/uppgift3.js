"use strict";

// creates an array with strings
let colors = ["Red", "Green", "Blue", "Black", "White"];

// looping over all the colors and logging each one.
for (let i = 0; i < colors.length; i++) {
    console.log(colors[i]);
}
console.log(`Antal värden: ${colors.length} stycken.`)