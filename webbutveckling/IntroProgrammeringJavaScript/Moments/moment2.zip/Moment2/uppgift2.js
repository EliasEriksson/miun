"use strict";
function multiply(num1, num2) {
    /**
     * a function that takes 2 numbers and multiply them together.
     *
     * the result is logged.
     */
    console.log(`${num1} * ${num2} = ${num1 * num2}`);
}

// calling the function
multiply(2, 4);
