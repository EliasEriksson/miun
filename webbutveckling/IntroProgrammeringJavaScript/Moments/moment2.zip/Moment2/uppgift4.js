"use strict";

// looping over a range of numbers and logging all the odd ones.
for (let i = 3; i <= 23; i++) {
    if (i % 2 === 1) {
        console.log(i);
    }
}