"use strict";
let firstname = "Elias";
let lastname = "Eriksson";
let mail = "eler2006@miun.student.se";

// formatting a string
let formattedString = `${firstname} ${lastname}, ${mail}`;

// logging the string
console.log(formattedString);
