<?php
include __DIR__."/../utils/config.php";
?>

<header>
    <h1>Moment 2 - Objektorienterad programmering</h1>
</header>