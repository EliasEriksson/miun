<?php
include "../utils/config.php";
?>

<!doctype html>
<html lang="en">
<head>
    <?php
    include "../templates/head.php";
    ?>
    <title>Moment 2 - TEST</title>
</head>
<body>
<?php
include "../templates/header.php";
?>

<?php
?>

<?php
include "../templates/footer.php";
?>
</body>
</html>