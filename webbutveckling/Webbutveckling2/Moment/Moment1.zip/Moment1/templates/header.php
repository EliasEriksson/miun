<header>
    <nav class="menu-horizontal">
        <a href="<?=$rootURL?>">Hem</a>
        <a href="<?=$rootURL?>/Variabler/">Variabler</a>
        <a href="<?=$rootURL?>/Villkor/">Villkor</a>
        <a href="<?=$rootURL?>/Formulär/">Formulär</a>
        <a href="<?=$rootURL?>/Filer/">Filer</a>
    </nav>
</header>