<?php
$rootURL = dirname($_SERVER["SCRIPT_NAME"]) . "/..";
